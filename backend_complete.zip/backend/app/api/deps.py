from typing import Generator
from sqlalchemy.orm import Session
from fastapi import Depends
from app.db.session import SessionLocal


def get_db() -> Generator[Session, None, None]:
    """Dependency that provides a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()